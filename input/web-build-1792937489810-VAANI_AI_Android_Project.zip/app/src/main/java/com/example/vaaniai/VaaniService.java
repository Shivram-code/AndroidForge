package com.example.vaaniai;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import java.util.*;

public class VaaniService extends Service implements TextToSpeech.OnInitListener {
    private static final String CHANNEL = "vaani_listening";
    private SpeechRecognizer recognizer;
    private Intent speechIntent;
    private TextToSpeech tts;
    private boolean ready = false;
    private boolean waitingForCommand = false;
    private boolean stopping = false;
    private Handler handler;
    private CameraManager cameraManager;
    private String cameraId;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        tts = new TextToSpeech(this, this);
        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            String[] ids = cameraManager.getCameraIdList();
            for (String id : ids) {
                Boolean flash = cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) { cameraId = id; break; }
            }
        } catch (Exception ignored) {}
        createNotificationChannel();
        Notification n = new Notification.Builder(this, CHANNEL)
            .setContentTitle("VAANI AI is listening")
            .setContentText("Say “Hey Vaani” to activate")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else startForeground(7, n);

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onError(int error) { scheduleListen(700); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) handleText(matches.get(0));
                    scheduleListen(500);
                }
                @Override public void onPartialResults(Bundle partialResults) {}
                @Override public void onEvent(int eventType, Bundle params) {}
            });
            speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            scheduleListen(900);
        } else speak("Is phone par speech recognition available nahi hai.");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        stopping = false;
        return START_STICKY;
    }

    private void scheduleListen(long delay) {
        if (handler == null || stopping || recognizer == null) return;
        handler.postDelayed(() -> {
            if (!stopping && recognizer != null) {
                try { recognizer.startListening(speechIntent); } catch (Exception ignored) {}
            }
        }, delay);
    }

    private void handleText(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (!waitingForCommand) {
            if (s.contains("hey vaani") || s.contains("हे वाणी") || s.contains("हाय वाणी") || s.equals("vaani") || s.equals("वाणी")) {
                waitingForCommand = true;
                speak("जी, बताइए");
            }
            return;
        }
        waitingForCommand = false;
        if (s.contains("time") || s.contains("समय") || s.contains("टाइम")) {
            String time = new java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
            speak("अभी समय है " + time);
        } else if (s.contains("torch on") || s.contains("टॉर्च चालू") || s.contains("flashlight on")) {
            setTorch(true);
        } else if (s.contains("torch off") || s.contains("टॉर्च बंद") || s.contains("flashlight off")) {
            setTorch(false);
        } else if (s.contains("volume up") || s.contains("आवाज़ बढ़") || s.contains("वॉल्यूम बढ़")) {
            AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            speak("वॉल्यूम बढ़ा दिया");
        } else if (s.contains("volume down") || s.contains("आवाज़ कम") || s.contains("वॉल्यूम कम")) {
            AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            speak("वॉल्यूम कम कर दिया");
        } else if (s.contains("youtube")) {
            openApp("com.google.android.youtube", "YouTube");
        } else if (s.contains("camera") || s.contains("कैमरा")) {
            Intent i = new Intent("android.media.action.IMAGE_CAPTURE");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); speak("कैमरा खोल रहा हूँ"); } catch (Exception e) { speak("कैमरा नहीं खुल पाया"); }
        } else if (s.contains("stop listening") || s.contains("बंद हो जाओ") || s.contains("सुनना बंद")) {
            speak("ठीक है, VAANI बंद हो रहा है");
            handler.postDelayed(() -> stopSelf(), 1200);
        } else {
            speak("माफ़ कीजिए, यह कमांड अभी उपलब्ध नहीं है।");
        }
    }

    private void openApp(String packageName, String label) {
        Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
        if (i == null) { speak(label + " ऐप नहीं मिला"); return; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); speak(label + " खोल रहा हूँ"); }
        catch (Exception e) { speak(label + " नहीं खुल पाया"); }
    }

    private void setTorch(boolean on) {
        if (cameraId == null) { speak("इस फोन में टॉर्च उपलब्ध नहीं है"); return; }
        try {
            cameraManager.setTorchMode(cameraId, on);
            speak(on ? "टॉर्च चालू कर दी" : "टॉर्च बंद कर दी");
        } catch (Exception e) { speak("टॉर्च कंट्रोल नहीं हो पाया"); }
    }

    private void speak(String message) {
        if (tts != null && ready) {
            tts.setLanguage(new Locale("hi", "IN"));
            tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "vaani_reply");
        }
    }

    @Override public void onInit(int status) {
        ready = status == TextToSpeech.SUCCESS;
        if (ready) {
            tts.setLanguage(new Locale("hi", "IN"));
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "VAANI listening", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        stopping = true;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); recognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
