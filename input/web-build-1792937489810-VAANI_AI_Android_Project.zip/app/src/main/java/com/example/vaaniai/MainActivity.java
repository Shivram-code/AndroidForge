package com.example.vaaniai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private static final int REQ = 101;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 16, 38));
        getWindow().setNavigationBarColor(Color.rgb(7, 16, 38));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 36, 28, 36);
        root.setBackgroundColor(Color.rgb(7, 16, 38));

        TextView title = new TextView(this);
        title.setText("VAANI AI");
        title.setTextSize(34);
        title.setTextColor(Color.rgb(80, 220, 255));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("Your voice. Your assistant.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 30);

        TextView mic = new TextView(this);
        mic.setText("◉");
        mic.setTextSize(70);
        mic.setTextColor(Color.rgb(80, 220, 255));
        mic.setGravity(Gravity.CENTER);
        mic.setPadding(0, 10, 0, 10);

        status = new TextView(this);
        status.setText("Assistant is stopped");
        status.setTextSize(16);
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 12, 0, 24);

        Button start = new Button(this);
        start.setText("START VAANI");
        Button stop = new Button(this);
        stop.setText("STOP VAANI");

        TextView help = new TextView(this);
        help.setText("Say “Hey Vaani”, then try: “YouTube kholo”, “camera kholo”, “torch on”, “time batao”, or “volume badhao”.\n\nKeep the ongoing notification visible while listening.");
        help.setTextColor(Color.LTGRAY);
        help.setTextSize(14);
        help.setGravity(Gravity.CENTER);
        help.setPadding(0, 24, 0, 0);

        root.addView(title);
        root.addView(subtitle);
        root.addView(mic);
        root.addView(status);
        root.addView(start);
        root.addView(stop);
        root.addView(help);
        setContentView(root);

        start.setOnClickListener(v -> requestAndStart());
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, VaaniService.class));
            status.setText("Assistant stopped");
        });
    }

    private void requestAndStart() {
        String[] perms;
        if (Build.VERSION.SDK_INT >= 33) {
            perms = new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS};
        } else {
            perms = new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA};
        }
        boolean missing = false;
        for (String p : perms) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing = true;
        if (missing) {
            requestPermissions(perms, REQ);
        } else startAssistant();
    }

    private void startAssistant() {
        Intent i = new Intent(this, VaaniService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Listening for “Hey Vaani”…");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ) {
            boolean ok = true;
            for (int r : grantResults) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            if (ok) startAssistant();
            else status.setText("Microphone permission is required. Allow it in Settings.");
        }
    }
}
