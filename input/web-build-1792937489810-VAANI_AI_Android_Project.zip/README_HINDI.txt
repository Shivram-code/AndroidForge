VAANI AI — Android starter project

इस ZIP में Android Studio/Android IDE के लिए शुरुआती Java प्रोजेक्ट है।

महत्वपूर्ण:
- यह एक prototype है, तैयार/परीक्षित APK नहीं।
- “Hey Vaani” wake-word पहचान SpeechRecognizer पर आधारित है। Android/फोन निर्माता, इंटरनेट, बैटरी ऑप्टिमाइज़ेशन और OS की सीमाओं के कारण लगातार सुनना रुक सकता है या बार-बार अनुमति माँग सकता है।
- Android के नए संस्करण में माइक्रोफोन foreground service शुरू करने के लिए ऐप पहले खोलना और permission देना जरूरी हो सकता है।
- अभी शामिल कमांड: Hey Vaani, समय बताओ, टॉर्च चालू/बंद, वॉल्यूम बढ़ाओ/कम करो, YouTube खोलो, कैमरा खोलो, सुनना बंद करो।
- फोन लॉक रहते हुए हर कमांड काम नहीं करेगी। यह पासवर्ड/लॉक स्क्रीन bypass नहीं करता।
- ऐप के बंद/स्वाइप किए जाने के बाद भी सेवा हर फोन पर चलने की गारंटी नहीं है।

मोबाइल से इस्तेमाल:
1. Android पर कोई भरोसेमंद Android IDE/build environment इंस्टॉल करें जो Gradle Android projects build कर सके।
2. ZIP को extract करें और project folder खोलें।
3. Gradle sync/build करें; जरूरत हो तो Android SDK 35 और JDK 17 सेट करें।
4. APK install करें, VAANI AI खोलें और microphone/camera/notification permissions दें।
5. START VAANI दबाएँ। ongoing notification दिखाई देनी चाहिए।
6. बोलें: “Hey Vaani”, फिर command दें।

यदि build में error आए, error का screenshot/text भेजें; उसके अनुसार project सुधार सकते हैं।
